function calcular(){	
	var numero = document.getElementById("numero").value;
	numero = numero * 3;
	alert("Número: "+numero);
}